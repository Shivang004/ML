```python
import pandas as pd
```


```python
data=pd.read_csv("car.csv")
```


```python
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Brand</th>
      <th>Price</th>
      <th>Body</th>
      <th>Mileage</th>
      <th>EngineV</th>
      <th>Engine Type</th>
      <th>Registration</th>
      <th>Year</th>
      <th>Model</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>BMW</td>
      <td>4200.0</td>
      <td>sedan</td>
      <td>277</td>
      <td>2.0</td>
      <td>Petrol</td>
      <td>yes</td>
      <td>1991</td>
      <td>320</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Mercedes-Benz</td>
      <td>7900.0</td>
      <td>van</td>
      <td>427</td>
      <td>2.9</td>
      <td>Diesel</td>
      <td>yes</td>
      <td>1999</td>
      <td>Sprinter 212</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Mercedes-Benz</td>
      <td>13300.0</td>
      <td>sedan</td>
      <td>358</td>
      <td>5.0</td>
      <td>Gas</td>
      <td>yes</td>
      <td>2003</td>
      <td>S 500</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Audi</td>
      <td>23000.0</td>
      <td>crossover</td>
      <td>240</td>
      <td>4.2</td>
      <td>Petrol</td>
      <td>yes</td>
      <td>2007</td>
      <td>Q7</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Toyota</td>
      <td>18300.0</td>
      <td>crossover</td>
      <td>120</td>
      <td>2.0</td>
      <td>Petrol</td>
      <td>yes</td>
      <td>2011</td>
      <td>Rav 4</td>
    </tr>
  </tbody>
</table>
</div>




```python
pd.set_option('display.max_rows',10)
```


```python
data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Brand</th>
      <th>Price</th>
      <th>Body</th>
      <th>Mileage</th>
      <th>EngineV</th>
      <th>Engine Type</th>
      <th>Registration</th>
      <th>Year</th>
      <th>Model</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>BMW</td>
      <td>4200.0</td>
      <td>sedan</td>
      <td>277</td>
      <td>2.0</td>
      <td>Petrol</td>
      <td>yes</td>
      <td>1991</td>
      <td>320</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Mercedes-Benz</td>
      <td>7900.0</td>
      <td>van</td>
      <td>427</td>
      <td>2.9</td>
      <td>Diesel</td>
      <td>yes</td>
      <td>1999</td>
      <td>Sprinter 212</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Mercedes-Benz</td>
      <td>13300.0</td>
      <td>sedan</td>
      <td>358</td>
      <td>5.0</td>
      <td>Gas</td>
      <td>yes</td>
      <td>2003</td>
      <td>S 500</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Audi</td>
      <td>23000.0</td>
      <td>crossover</td>
      <td>240</td>
      <td>4.2</td>
      <td>Petrol</td>
      <td>yes</td>
      <td>2007</td>
      <td>Q7</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Toyota</td>
      <td>18300.0</td>
      <td>crossover</td>
      <td>120</td>
      <td>2.0</td>
      <td>Petrol</td>
      <td>yes</td>
      <td>2011</td>
      <td>Rav 4</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>4340</th>
      <td>Mercedes-Benz</td>
      <td>125000.0</td>
      <td>sedan</td>
      <td>9</td>
      <td>3.0</td>
      <td>Diesel</td>
      <td>yes</td>
      <td>2014</td>
      <td>S 350</td>
    </tr>
    <tr>
      <th>4341</th>
      <td>BMW</td>
      <td>6500.0</td>
      <td>sedan</td>
      <td>1</td>
      <td>3.5</td>
      <td>Petrol</td>
      <td>yes</td>
      <td>1999</td>
      <td>535</td>
    </tr>
    <tr>
      <th>4342</th>
      <td>BMW</td>
      <td>8000.0</td>
      <td>sedan</td>
      <td>194</td>
      <td>2.0</td>
      <td>Petrol</td>
      <td>yes</td>
      <td>1985</td>
      <td>520</td>
    </tr>
    <tr>
      <th>4343</th>
      <td>Toyota</td>
      <td>14200.0</td>
      <td>sedan</td>
      <td>31</td>
      <td>NaN</td>
      <td>Petrol</td>
      <td>yes</td>
      <td>2014</td>
      <td>Corolla</td>
    </tr>
    <tr>
      <th>4344</th>
      <td>Volkswagen</td>
      <td>13500.0</td>
      <td>van</td>
      <td>124</td>
      <td>2.0</td>
      <td>Diesel</td>
      <td>yes</td>
      <td>2013</td>
      <td>T5 (Transporter)</td>
    </tr>
  </tbody>
</table>
<p>4345 rows × 9 columns</p>
</div>




```python
data.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Price</th>
      <th>Mileage</th>
      <th>EngineV</th>
      <th>Year</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>4173.000000</td>
      <td>4345.000000</td>
      <td>4195.000000</td>
      <td>4345.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>19418.746935</td>
      <td>161.237284</td>
      <td>2.790734</td>
      <td>2006.550058</td>
    </tr>
    <tr>
      <th>std</th>
      <td>25584.242620</td>
      <td>105.705797</td>
      <td>5.066437</td>
      <td>6.719097</td>
    </tr>
    <tr>
      <th>min</th>
      <td>600.000000</td>
      <td>0.000000</td>
      <td>0.600000</td>
      <td>1969.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>6999.000000</td>
      <td>86.000000</td>
      <td>1.800000</td>
      <td>2003.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>11500.000000</td>
      <td>155.000000</td>
      <td>2.200000</td>
      <td>2008.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>21700.000000</td>
      <td>230.000000</td>
      <td>3.000000</td>
      <td>2012.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>300000.000000</td>
      <td>980.000000</td>
      <td>99.990000</td>
      <td>2016.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
data=data.dropna(axis=0)
```


```python
y=data.Price
```


```python
x=data[['Brand','Body','Mileage','EngineV','Engine Type']]
```


```python
x.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Brand</th>
      <th>Body</th>
      <th>Mileage</th>
      <th>EngineV</th>
      <th>Engine Type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>BMW</td>
      <td>sedan</td>
      <td>277</td>
      <td>2.0</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Mercedes-Benz</td>
      <td>van</td>
      <td>427</td>
      <td>2.9</td>
      <td>Diesel</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Mercedes-Benz</td>
      <td>sedan</td>
      <td>358</td>
      <td>5.0</td>
      <td>Gas</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Audi</td>
      <td>crossover</td>
      <td>240</td>
      <td>4.2</td>
      <td>Petrol</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Toyota</td>
      <td>crossover</td>
      <td>120</td>
      <td>2.0</td>
      <td>Petrol</td>
    </tr>
  </tbody>
</table>
</div>




```python
x.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Mileage</th>
      <th>EngineV</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>4025.000000</td>
      <td>4025.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>163.572174</td>
      <td>2.764586</td>
    </tr>
    <tr>
      <th>std</th>
      <td>103.394703</td>
      <td>4.935941</td>
    </tr>
    <tr>
      <th>min</th>
      <td>0.000000</td>
      <td>0.600000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>90.000000</td>
      <td>1.800000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>158.000000</td>
      <td>2.200000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>230.000000</td>
      <td>3.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>980.000000</td>
      <td>99.990000</td>
    </tr>
  </tbody>
</table>
</div>




```python
from sklearn.preprocessing import LabelEncoder
```


```python
data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Brand</th>
      <th>Price</th>
      <th>Body</th>
      <th>Mileage</th>
      <th>EngineV</th>
      <th>Engine Type</th>
      <th>Registration</th>
      <th>Year</th>
      <th>Model</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>BMW</td>
      <td>4200.0</td>
      <td>sedan</td>
      <td>277</td>
      <td>2.0</td>
      <td>Petrol</td>
      <td>yes</td>
      <td>1991</td>
      <td>320</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Mercedes-Benz</td>
      <td>7900.0</td>
      <td>van</td>
      <td>427</td>
      <td>2.9</td>
      <td>Diesel</td>
      <td>yes</td>
      <td>1999</td>
      <td>Sprinter 212</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Mercedes-Benz</td>
      <td>13300.0</td>
      <td>sedan</td>
      <td>358</td>
      <td>5.0</td>
      <td>Gas</td>
      <td>yes</td>
      <td>2003</td>
      <td>S 500</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Audi</td>
      <td>23000.0</td>
      <td>crossover</td>
      <td>240</td>
      <td>4.2</td>
      <td>Petrol</td>
      <td>yes</td>
      <td>2007</td>
      <td>Q7</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Toyota</td>
      <td>18300.0</td>
      <td>crossover</td>
      <td>120</td>
      <td>2.0</td>
      <td>Petrol</td>
      <td>yes</td>
      <td>2011</td>
      <td>Rav 4</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>4339</th>
      <td>Toyota</td>
      <td>17900.0</td>
      <td>sedan</td>
      <td>35</td>
      <td>1.6</td>
      <td>Petrol</td>
      <td>yes</td>
      <td>2014</td>
      <td>Corolla</td>
    </tr>
    <tr>
      <th>4340</th>
      <td>Mercedes-Benz</td>
      <td>125000.0</td>
      <td>sedan</td>
      <td>9</td>
      <td>3.0</td>
      <td>Diesel</td>
      <td>yes</td>
      <td>2014</td>
      <td>S 350</td>
    </tr>
    <tr>
      <th>4341</th>
      <td>BMW</td>
      <td>6500.0</td>
      <td>sedan</td>
      <td>1</td>
      <td>3.5</td>
      <td>Petrol</td>
      <td>yes</td>
      <td>1999</td>
      <td>535</td>
    </tr>
    <tr>
      <th>4342</th>
      <td>BMW</td>
      <td>8000.0</td>
      <td>sedan</td>
      <td>194</td>
      <td>2.0</td>
      <td>Petrol</td>
      <td>yes</td>
      <td>1985</td>
      <td>520</td>
    </tr>
    <tr>
      <th>4344</th>
      <td>Volkswagen</td>
      <td>13500.0</td>
      <td>van</td>
      <td>124</td>
      <td>2.0</td>
      <td>Diesel</td>
      <td>yes</td>
      <td>2013</td>
      <td>T5 (Transporter)</td>
    </tr>
  </tbody>
</table>
<p>4025 rows × 9 columns</p>
</div>




```python
le=LabelEncoder()
label1=le.fit_transform(data['Brand'])
label2=le.fit_transform(data['Body'])
label3=le.fit_transform(data['Engine Type'])
label4=le.fit_transform(data['Model'])
```


```python
label4
```




    array([ 18, 261, 232, ...,  37,  31, 278])




```python
Newdata=data.drop(["Brand","Body","Engine Type","Model"],axis="columns")
```


```python
Newdata.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Price</th>
      <th>Mileage</th>
      <th>EngineV</th>
      <th>Registration</th>
      <th>Year</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>4200.0</td>
      <td>277</td>
      <td>2.0</td>
      <td>yes</td>
      <td>1991</td>
    </tr>
    <tr>
      <th>1</th>
      <td>7900.0</td>
      <td>427</td>
      <td>2.9</td>
      <td>yes</td>
      <td>1999</td>
    </tr>
    <tr>
      <th>2</th>
      <td>13300.0</td>
      <td>358</td>
      <td>5.0</td>
      <td>yes</td>
      <td>2003</td>
    </tr>
    <tr>
      <th>3</th>
      <td>23000.0</td>
      <td>240</td>
      <td>4.2</td>
      <td>yes</td>
      <td>2007</td>
    </tr>
    <tr>
      <th>4</th>
      <td>18300.0</td>
      <td>120</td>
      <td>2.0</td>
      <td>yes</td>
      <td>2011</td>
    </tr>
  </tbody>
</table>
</div>




```python
Newdata["Brand"]=label1
```


```python
Newdata["Body"]=label2
```


```python
Newdata["Engine Type"]=label3
```


```python
Newdata["Model"]=label4
```


```python
Newdata
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Price</th>
      <th>Mileage</th>
      <th>EngineV</th>
      <th>Registration</th>
      <th>Year</th>
      <th>Brand</th>
      <th>Body</th>
      <th>Engine Type</th>
      <th>Model</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>4200.0</td>
      <td>277</td>
      <td>2.0</td>
      <td>yes</td>
      <td>1991</td>
      <td>1</td>
      <td>3</td>
      <td>3</td>
      <td>18</td>
    </tr>
    <tr>
      <th>1</th>
      <td>7900.0</td>
      <td>427</td>
      <td>2.9</td>
      <td>yes</td>
      <td>1999</td>
      <td>2</td>
      <td>5</td>
      <td>0</td>
      <td>261</td>
    </tr>
    <tr>
      <th>2</th>
      <td>13300.0</td>
      <td>358</td>
      <td>5.0</td>
      <td>yes</td>
      <td>2003</td>
      <td>2</td>
      <td>3</td>
      <td>1</td>
      <td>232</td>
    </tr>
    <tr>
      <th>3</th>
      <td>23000.0</td>
      <td>240</td>
      <td>4.2</td>
      <td>yes</td>
      <td>2007</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>219</td>
    </tr>
    <tr>
      <th>4</th>
      <td>18300.0</td>
      <td>120</td>
      <td>2.0</td>
      <td>yes</td>
      <td>2011</td>
      <td>5</td>
      <td>0</td>
      <td>3</td>
      <td>222</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>4339</th>
      <td>17900.0</td>
      <td>35</td>
      <td>1.6</td>
      <td>yes</td>
      <td>2014</td>
      <td>5</td>
      <td>3</td>
      <td>3</td>
      <td>110</td>
    </tr>
    <tr>
      <th>4340</th>
      <td>125000.0</td>
      <td>9</td>
      <td>3.0</td>
      <td>yes</td>
      <td>2014</td>
      <td>2</td>
      <td>3</td>
      <td>0</td>
      <td>228</td>
    </tr>
    <tr>
      <th>4341</th>
      <td>6500.0</td>
      <td>1</td>
      <td>3.5</td>
      <td>yes</td>
      <td>1999</td>
      <td>1</td>
      <td>3</td>
      <td>3</td>
      <td>37</td>
    </tr>
    <tr>
      <th>4342</th>
      <td>8000.0</td>
      <td>194</td>
      <td>2.0</td>
      <td>yes</td>
      <td>1985</td>
      <td>1</td>
      <td>3</td>
      <td>3</td>
      <td>31</td>
    </tr>
    <tr>
      <th>4344</th>
      <td>13500.0</td>
      <td>124</td>
      <td>2.0</td>
      <td>yes</td>
      <td>2013</td>
      <td>6</td>
      <td>5</td>
      <td>0</td>
      <td>278</td>
    </tr>
  </tbody>
</table>
<p>4025 rows × 9 columns</p>
</div>




```python
Y=Newdata["Price"]
```


```python
X=Newdata[['Brand','Body','Mileage','EngineV','Engine Type','Model']]
X.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Brand</th>
      <th>Body</th>
      <th>Mileage</th>
      <th>EngineV</th>
      <th>Engine Type</th>
      <th>Model</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>3</td>
      <td>277</td>
      <td>2.0</td>
      <td>3</td>
      <td>18</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>5</td>
      <td>427</td>
      <td>2.9</td>
      <td>0</td>
      <td>261</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>3</td>
      <td>358</td>
      <td>5.0</td>
      <td>1</td>
      <td>232</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0</td>
      <td>0</td>
      <td>240</td>
      <td>4.2</td>
      <td>3</td>
      <td>219</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>0</td>
      <td>120</td>
      <td>2.0</td>
      <td>3</td>
      <td>222</td>
    </tr>
  </tbody>
</table>
</div>




```python
from sklearn.tree import DecisionTreeRegressor
```


```python
model=DecisionTreeRegressor(random_state=1)
```


```python
model.fit(X,Y)
```




<style>#sk-container-id-4 {color: black;background-color: white;}#sk-container-id-4 pre{padding: 0;}#sk-container-id-4 div.sk-toggleable {background-color: white;}#sk-container-id-4 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-4 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-4 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-4 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-4 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-4 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-4 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-4 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-4 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-4 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-4 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-4 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-4 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-4 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-4 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-4 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-4 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-4 div.sk-item {position: relative;z-index: 1;}#sk-container-id-4 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-4 div.sk-item::before, #sk-container-id-4 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-4 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-4 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-4 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-4 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-4 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-4 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-4 div.sk-label-container {text-align: center;}#sk-container-id-4 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-4 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-4" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>DecisionTreeRegressor(random_state=1)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-4" type="checkbox" checked><label for="sk-estimator-id-4" class="sk-toggleable__label sk-toggleable__label-arrow">DecisionTreeRegressor</label><div class="sk-toggleable__content"><pre>DecisionTreeRegressor(random_state=1)</pre></div></div></div></div></div>




```python
print("Making predictions for the following 5 cars:")
print(X.head())
print("The predictions are")
print(model.predict(X.head()))
```

    Making predictions for the following 5 cars:
       Brand  Body  Mileage  EngineV  Engine Type  Model
    0      1     3      277      2.0            3     18
    1      2     5      427      2.9            0    261
    2      2     3      358      5.0            1    232
    3      0     0      240      4.2            3    219
    4      5     0      120      2.0            3    222
    The predictions are
    [ 4200.  7900. 13300. 23000. 16900.]
    


```python
Y.head()
```




    0     4200.0
    1     7900.0
    2    13300.0
    3    23000.0
    4    18300.0
    Name: Price, dtype: float64




```python
pd.set_option('display.max_rows', 25)
```


```python
data.loc[Newdata['Price'] == max(Newdata['Price'])]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Brand</th>
      <th>Price</th>
      <th>Body</th>
      <th>Mileage</th>
      <th>EngineV</th>
      <th>Engine Type</th>
      <th>Registration</th>
      <th>Year</th>
      <th>Model</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1728</th>
      <td>Mercedes-Benz</td>
      <td>300000.0</td>
      <td>sedan</td>
      <td>68</td>
      <td>6.0</td>
      <td>Petrol</td>
      <td>yes</td>
      <td>2011</td>
      <td>S 600</td>
    </tr>
    <tr>
      <th>4318</th>
      <td>Mercedes-Benz</td>
      <td>300000.0</td>
      <td>other</td>
      <td>37</td>
      <td>5.0</td>
      <td>Petrol</td>
      <td>yes</td>
      <td>2012</td>
      <td>G 500</td>
    </tr>
  </tbody>
</table>
</div>




```python
print(max(Newdata['Price']))
```

    300000.0
    


```python
Newdata.loc[Newdata['Price'] == max(Newdata['Price'])]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Price</th>
      <th>Mileage</th>
      <th>EngineV</th>
      <th>Registration</th>
      <th>Year</th>
      <th>Brand</th>
      <th>Body</th>
      <th>Engine Type</th>
      <th>Model</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1728</th>
      <td>300000.0</td>
      <td>68</td>
      <td>6.0</td>
      <td>yes</td>
      <td>2011</td>
      <td>2</td>
      <td>3</td>
      <td>3</td>
      <td>235</td>
    </tr>
    <tr>
      <th>4318</th>
      <td>300000.0</td>
      <td>37</td>
      <td>5.0</td>
      <td>yes</td>
      <td>2012</td>
      <td>2</td>
      <td>2</td>
      <td>3</td>
      <td>124</td>
    </tr>
  </tbody>
</table>
</div>




```python
testdata=pd.read_csv("carTest.csv")
testdata.columns=['Brand','Body','Mileage','EngineV','Engine Type','Model']
testdata
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Brand</th>
      <th>Body</th>
      <th>Mileage</th>
      <th>EngineV</th>
      <th>Engine Type</th>
      <th>Model</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>0</td>
      <td>240</td>
      <td>4.2</td>
      <td>3</td>
      <td>219</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5</td>
      <td>1</td>
      <td>120</td>
      <td>2.0</td>
      <td>2</td>
      <td>222</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>5.5</td>
      <td>3</td>
      <td>140</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>3</td>
      <td>438</td>
      <td>2.0</td>
      <td>1</td>
      <td>320</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0</td>
      <td>4</td>
      <td>150</td>
      <td>2.7</td>
      <td>0</td>
      <td>64</td>
    </tr>
    <tr>
      <th>5</th>
      <td>4</td>
      <td>4</td>
      <td>193</td>
      <td>1.6</td>
      <td>0</td>
      <td>150</td>
    </tr>
    <tr>
      <th>6</th>
      <td>6</td>
      <td>2</td>
      <td>212</td>
      <td>1.8</td>
      <td>1</td>
      <td>145</td>
    </tr>
    <tr>
      <th>7</th>
      <td>4</td>
      <td>4</td>
      <td>177</td>
      <td>1.5</td>
      <td>0</td>
      <td>194</td>
    </tr>
  </tbody>
</table>
</div>




```python
print("Making predictions for the following 8 cars:")
print(testdata)
print("The predictions are")
print(model.predict(testdata))
```

    Making predictions for the following 8 cars:
       Brand  Body  Mileage  EngineV  Engine Type  Model
    0      0     0      240      4.2            3    219
    1      5     1      120      2.0            2    222
    2      3     0        0      5.5            3    140
    3      1     3      438      2.0            1    320
    4      0     4      150      2.7            0     64
    5      4     4      193      1.6            0    150
    6      6     2      212      1.8            1    145
    7      4     4      177      1.5            0    194
    The predictions are
    [ 23000.   16900.  195399.2   7500.    4400.    7500.    1400.   11950. ]
    


```python
import matplotlib
import matplotlib.pyplot as plt
```


```python
Newdata["Brand"]
```




    0       1
    1       2
    2       2
    3       0
    4       5
           ..
    4339    5
    4340    2
    4341    1
    4342    1
    4344    6
    Name: Brand, Length: 4025, dtype: int32




```python
pd.options.display.max_rows
```




    25




```python
pd.options.display.max_rows = 4329
```


```python
Newdata["Brand"].head()
```




    0    1
    1    2
    2    2
    3    0
    4    5
    Name: Brand, dtype: int32




```python
Newdata.plot(x="Price",y=["Brand","Body","Mileage","Model"])
```




    <Axes: xlabel='Price'>




    
![png](output_40_1.png)
    



```python
Newdata.plot(y="Price",color='r')
```




    <Axes: >




    
![png](output_41_1.png)
    



```python
Newdata.plot("Price")
```




    <Axes: xlabel='Price'>




    
![png](output_42_1.png)
    



```python
data[1:40].plot(y="Price",x="Brand",kind='bar')
```




    <Axes: xlabel='Brand'>




    
![png](output_43_1.png)
    

